function Home() {
  return (
    <div>
      <h2>🏠 Home Page</h2>
      <p>Welcome to Home Page</p>
    </div>
  );
}

export default Home;
