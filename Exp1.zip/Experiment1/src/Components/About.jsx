function About() {
  return (
    <div>
      <h2>ℹ️ About Page</h2>
      <p>This is About Page</p>
    </div>
  );
}

export default About;
