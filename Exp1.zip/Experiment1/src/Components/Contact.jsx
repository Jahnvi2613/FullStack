function Contact() {
  return (
    <div>
      <h2>📞 Contact Page</h2>
      <p>Email: jahnvi6512@gmail.com</p>
      <p>Phone Number: 9459002416</p>

    </div>
  );
}

export default Contact;
