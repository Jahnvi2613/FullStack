function Footer() {
  return (
    <footer className="bg-dark text-white text-center p-3 mt-5">
      © 2026 My Portfolio | Built with React + Bootstrap
    </footer>
  );
}

export default Footer;
